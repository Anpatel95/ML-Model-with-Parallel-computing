# Project 2: Machine Learning Model Deployment Guide

## Create an EMR Cluster on AWS

1. Go to the AWS Console and search for EMR.
2. Create an EMR Cluster with the following parameters:
3. Number of EC2 instances: 5
4. Edit the security group of the master instance to allow SSH inbound from your IP.

## Spark EC2 Cluster Setup using FlintRock

1. SSH to the primary EC2 instance of the EMR Cluster.
2. Run the following commands:
    ```bash
    sudo yum update
    ```
3. Copy and paste AWS credentials to `~/.aws/credentials`.
4. Check if Python and Pip are installed:
    ```bash
    python --version
    pip --version
    ```
5. Install FlintRock:
    ```bash
    pip3 install flintrock
    ```
6. Configure FlintRock:
    ```bash
    flintrock configure
    ```
7. Edit `~/.config/flintrock/config.yaml` and replace key-name, key path, AMI, and desired slaves (4).
8. Start a multi-node cluster:
    ```bash
    flintrock launch ML_Training
    ```
9. Login to multi-node cluster
    ```bash
    flintrock login ML_Training
    ```
   
## Project Setup and Model Training

1. After logging into the ML_Training cluster:
    ```bash
    sudo yum install git -y
    ```
2. Clone the project
    ```bash
    git clone git@github.com:ap2684/Project_2_ML_Model.git
    ```
3. Run the following commands for compiling the application:
    ```bash
    cd /home/ec2-user/Project_2_ML_Model/Trainer_MLmodel/
    mvn clean install
    ```
4. Submit the Spark job for training:
    ```bash
    spark-submit --master spark://<master-node-ip>:7077 --class "org.project2.Main" target/<.jar file>
    ```

## Predicting and Testing the Model

### Predicting Without Docker

1. Run the following commands for compiling the application:
    ```bash
    cd /home/ec2-user/Project_2_ML_Model/Predict_MLmodel
    mvn clean install
    ```
2. Run the Spark job for predictions with ValidationDataset.csv dataset:
    ```bash
    spark-submit --class "org.project2.Main" target/<.jar file> ValidationDataset.csv
    ```

### Deploy and Predict with Docker

1. Check if Docker is installed:
    ```bash
    docker --version
    ```
2. Install Docker if not installed:
    ```bash
    sudo yum install -y docker
    ```
3. Start Docker service:
    ```bash
    sudo service docker start
    ```
4. Add the ec2-user to the docker group:
    ```bash
    sudo usermod -a -G docker ec2-user
    ```
5. Sign out and sign in to apply permissions.
6. Verify that the ec2-user can run Docker commands without sudo:
    ```bash
    docker ps
    ```
7. Build Docker Image:
    ```bash
    cd /home/ec2-user/Project_2_ML_Model/Predict_MLmodel
    docker build -t predict .
    ```
8. Verify the image is created:
    ```bash
    docker images --filter reference=predict
    ```
9. Run the application with Docker image:
    ```bash
    docker run -t -i -p 80:80 predict
    ```
This completes the setup and deployment process. You should now have a running Spark cluster and a deployed machine learning model accessible through Docker.