package org.project2;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.SparkConf;
import org.apache.spark.ml.classification.RandomForestClassificationModel;
import org.apache.spark.ml.classification.RandomForestClassifier;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructType;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException, URISyntaxException {

        //Spark Configuration
        SparkConf conf = new SparkConf()
                .setAppName("RandomForest");

        //Init Spark Session
        SparkSession spark = SparkSession.builder().config(conf).getOrCreate();

        // Define the schema for the Wine dataset
        StructType schema = new StructType()
                .add("fixed acidity", DataTypes.DoubleType, false)
                .add("volatile acidity", DataTypes.DoubleType, false)
                .add("citric acid", DataTypes.DoubleType, false)
                .add("residual sugar", DataTypes.DoubleType, false)
                .add("chlorides", DataTypes.DoubleType, false)
                .add("free sulfur dioxide", DataTypes.DoubleType, false)
                .add("total sulfur dioxide", DataTypes.DoubleType, false)
                .add("density", DataTypes.DoubleType, false)
                .add("pH", DataTypes.DoubleType, false)
                .add("sulphates", DataTypes.DoubleType, false)
                .add("alcohol", DataTypes.DoubleType, false)
                .add("quality", DataTypes.IntegerType, false);

        loadTestDataset();
        loadValidDataset();

        String userHome = System.getProperty("user.home");

        //load testing dataset
        Dataset<Row> training_data = spark.read()
                .option("delimiter", ";")
                .option("header", "true")
                .option("quote", "\"")
                .schema(schema)
                .csv("TrainingDataset.csv");

        String[] test_featureCols = training_data.columns();

        System.out.println("Feature Columns: " + Arrays.toString(test_featureCols));

        // assemble test dataset
        VectorAssembler test_assembler = new VectorAssembler()
                .setInputCols(test_featureCols)
                .setOutputCol("features");

        Dataset<Row> test_assembledData = test_assembler.transform(training_data);

        //load validation dataset
        Dataset<Row> validation_data = spark.read()
                .option("delimiter", ";")
                .option("header", "true")
                .option("quote", "\"")
                .schema(schema)
                .csv("ValidationDataset.csv");

        String[] valid_featureCols = validation_data.columns();

        // assemble validation dataset
        VectorAssembler valid_assembler = new VectorAssembler()
                .setInputCols(valid_featureCols)
                .setOutputCol("features");

        Dataset<Row> valid_assembledData = valid_assembler.transform(validation_data);


        // Create a random forest classifier
        RandomForestClassifier classifier = new RandomForestClassifier().setLabelCol("quality").setFeaturesCol("features");

        // Train the classifier
        RandomForestClassificationModel model = classifier.fit(test_assembledData);

        // testing the model
        Dataset<Row> predictions = model.transform(test_assembledData);


        MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
                .setLabelCol("quality")
                .setPredictionCol("prediction")
                .setMetricName("accuracy");

        MulticlassClassificationEvaluator f1Evaluator = new MulticlassClassificationEvaluator()
                .setLabelCol("quality")
                .setPredictionCol("prediction")
                .setMetricName("f1");


        double accuracy = evaluator.evaluate(predictions) * 100;
        double f1score = f1Evaluator.evaluate(predictions) * 100;

        accuracy = Math.round(accuracy);
        f1score = Math.round(f1score);

        // Print the accuracy
        System.out.println("Accuracy: ---------------" + accuracy + "\n");
        // Print the F1 Score
        System.out.println("F1 Score: ---------------" + f1score + "\n");

        //String hdfsPath = "hdfs://ip-172-31-43-8.ec2.internal:9000/user/ec2-user/save_mymodel";
        String hdfsPath = "hdfs:///user/ec2-user/save_mymodel";
        //store the model
        model.write().overwrite().save(hdfsPath);

        //store the trained model locally
        String localPath = userHome + "/Project_2_ML_Model/Predict_MLmodel/src/main/resources";

        FileSystem fs = FileSystem.get(new URI(hdfsPath), new Configuration());
        Path srcPath = new Path(hdfsPath);
        Path dstPath = new Path(localPath);

        //delete existing trained model
        String localPath_model = userHome + "/Project_2_ML_Model/Predict_MLmodel/src/main/resources/save_mymodel";

        File localDirectory = new File(localPath_model);

        if (localDirectory.exists()) {
            FileUtils.deleteDirectory(localDirectory);
            System.out.println("Local directory deleted successfully.");
        } else {
            System.out.println("Local directory does not exist.");
        }


        fs.copyToLocalFile(true, srcPath, dstPath);

        System.out.println("Training Completed.");
        fs.close();
        spark.stop();
    }

    public static void loadTestDataset() throws IOException {

        String localFilePath = "src/main/resources/TrainingDataset.csv";

        Configuration conf2 = new Configuration();
        FileSystem fs = FileSystem.get(conf2);

        // HDFS destination path
        String hdfsFilePath = "/user/ec2-user/TrainingDataset.csv";

        Path localPath = new Path(localFilePath);
        Path hdfsPath = new Path(hdfsFilePath);

        fs.copyFromLocalFile(localPath, hdfsPath);
        fs.close();
    }

    public static void loadValidDataset() throws IOException {

        String localFilePath2 = "src/main/resources/ValidationDataset.csv";

        Configuration conf3 = new Configuration();
        FileSystem fs1 = FileSystem.get(conf3);

        // HDFS destination path
        String hdfsFilePath1 = "/user/ec2-user/ValidationDataset.csv";

        Path localPath1 = new Path(localFilePath2);
        Path hdfsPath1 = new Path(hdfsFilePath1);

        fs1.copyFromLocalFile(localPath1, hdfsPath1);
        fs1.close();
    }
}