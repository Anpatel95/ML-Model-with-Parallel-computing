package org.project2;

import org.apache.spark.SparkConf;
import org.apache.spark.ml.classification.RandomForestClassificationModel;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructType;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {

        //checking for input file
        if (args.length > 0) {
            // Input provided
            System.out.println("Input received: " + args[0]);
        } else {
            // No input provided
            System.out.println("No input provided. Please provide input. e.g. ValidationDataset.csv");
            return;
        }

        //Spark Configuration
        SparkConf conf = new SparkConf()
                .setAppName("Predict ML model")
                .setMaster("local[*]");

        //Init Spark Session
        SparkSession spark = SparkSession.builder().config(conf).getOrCreate();

        // Define the schema for the Wine dataset
        StructType schema = new StructType()
                .add("fixed acidity", DataTypes.DoubleType, false)
                .add("volatile acidity", DataTypes.DoubleType, false)
                .add("citric acid", DataTypes.DoubleType, false)
                .add("residual sugar", DataTypes.DoubleType, false)
                .add("chlorides", DataTypes.DoubleType, false)
                .add("free sulfur dioxide", DataTypes.DoubleType, false)
                .add("total sulfur dioxide", DataTypes.DoubleType, false)
                .add("density", DataTypes.DoubleType, false)
                .add("pH", DataTypes.DoubleType, false)
                .add("sulphates", DataTypes.DoubleType, false)
                .add("alcohol", DataTypes.DoubleType, false)
                .add("quality", DataTypes.IntegerType, false);

        // Get the current working directory
        String currentDirectory = System.getProperty("user.dir");

        // Print the current working directory
        System.out.println("Current working directory: " + currentDirectory + "\n");


        String csv_dataset_path = "file://" + System.getProperty("user.dir") + "/src/main/resources/" + args[0];
        Dataset<Row> validation_data = spark.read()
                .option("delimiter", ";")
                .option("header", "true")
                .option("quote", "\"")
                .schema(schema)
                .csv(csv_dataset_path);


        String[] valid_featureCols = validation_data.columns();
        // assemble validation dataset
        VectorAssembler valid_assembler = new VectorAssembler()
                .setInputCols(valid_featureCols)
                .setOutputCol("features");

        Dataset<Row> valid_assembledData = valid_assembler.transform(validation_data);

        // Load the model from HDFS
        try {

            String trainedmodel_path = "file://" + System.getProperty("user.dir") + "/src/main/resources/save_mymodel";

            RandomForestClassificationModel loadedModel = RandomForestClassificationModel.load(trainedmodel_path);

            MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
                    .setLabelCol("quality")
                    .setPredictionCol("prediction")
                    .setMetricName("accuracy");

            MulticlassClassificationEvaluator f1Evaluator = new MulticlassClassificationEvaluator()
                    .setLabelCol("quality")
                    .setPredictionCol("prediction")
                    .setMetricName("f1");

            Dataset<Row> predictions = loadedModel.transform(valid_assembledData);

            double accuracy = evaluator.evaluate(predictions) * 100;
            double f1score = f1Evaluator.evaluate(predictions) * 100;

            f1score = Math.round(f1score);
            // Print the accuracy
            System.out.println("Testing Accuracy: ---------------" + accuracy + "\n");
            // Print the F1 Score
            System.out.println("Testing F1 Score: ---------------" + f1score + "\n");

        } catch (Exception e) {
            e.printStackTrace();
        }

        spark.stop();
    }

}